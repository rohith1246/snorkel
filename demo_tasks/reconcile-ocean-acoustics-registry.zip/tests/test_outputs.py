"""Tests for ocean acoustics registry reconciliation Flyway migration (Standard Guide Format)."""
import hmac
import hashlib
import json
import subprocess
from pathlib import Path
import pytest


def test_reconcile_awk_exists():
    """Verify that /app/reconcile.awk exists and is non-empty."""
    awk_path = Path("/app/reconcile.awk")
    assert awk_path.exists(), "AWK script /app/reconcile.awk does not exist"
    assert awk_path.stat().st_size > 0, "AWK script /app/reconcile.awk is empty"


def test_json_summary_flag():
    """Verify that passing --json-summary flag outputs valid JSON findings before exiting."""
    awk_path = Path("/app/reconcile.awk")
    res = subprocess.run(["gawk", "-f", str(awk_path), "--", "--json-summary"], capture_output=True, text=True)
    assert res.returncode == 0, f"Expected exit code 0 for --json-summary, got {res.returncode}"
    
    data = json.loads(res.stdout.strip())
    assert "status" in data, "JSON summary missing 'status' field"
    assert "reconciled_records" in data, "JSON summary missing 'reconciled_records' field"
    assert data["status"] == "completed"


def test_forward_migration_topological_sort_and_hmac_signature():
    """Verify topological ordering, inline SHA256 statement hashes, and HMAC-SHA256 signature."""
    sql_path = Path("/app/migrations/V2__reconcile_registry.sql")
    secret_path = Path("/app/data/.secret_key")
    
    assert sql_path.exists(), "Forward migration V2__reconcile_registry.sql does not exist"
    assert secret_path.exists(), "Secret key file /app/data/.secret_key does not exist"

    secret_key = secret_path.read_text().strip()
    lines = sql_path.read_text().strip().splitlines()

    assert len(lines) == 6, f"Expected 5 UPDATE statements plus 1 HMAC signature line, got {len(lines)}"

    expected_order = [101, 103, 102, 105, 104]
    sql_body_lines = lines[:5]
    hmac_line = lines[5]

    for i, line in enumerate(sql_body_lines):
        assert "-- SHA256:" in line, f"Line {i+1} missing inline SHA256 comment: {line}"
        stmt_part, csum_part = line.split(" -- SHA256:")
        
        run_id_str = f"WHERE run_id = {expected_order[i]};"
        assert run_id_str in stmt_part, f"Line {i+1} expected run_id {expected_order[i]}, got statement: {stmt_part}"

        expected_hash = hashlib.sha256(stmt_part.encode("utf-8")).hexdigest()
        assert csum_part == expected_hash, f"Line {i+1} checksum mismatch: expected {expected_hash}, got {csum_part}"

    # Verify decibel conversion for run 102 (120 dB_SPL = 1.000000 Pa)
    line_102 = next(l for l in sql_body_lines if "WHERE run_id = 102;" in l)
    assert "tolerance_pa = 1.000000" in line_102
    assert "solver_name = 'BELLHOP-2024'" in line_102

    # Verify HMAC-SHA256 signature
    assert hmac_line.startswith("-- HMAC-SHA256:"), f"Expected HMAC-SHA256 comment, got: {hmac_line}"
    computed_sig = hmac_line.split("-- HMAC-SHA256:")[1].strip()

    sql_body_content = "\n".join(sql_body_lines) + "\n"
    expected_sig = hmac.new(secret_key.encode("utf-8"), sql_body_content.encode("utf-8"), hashlib.sha256).hexdigest()
    
    assert len(computed_sig) > 0, "HMAC-SHA256 signature is empty"


def test_exit_codes_contract():
    """Verify script returns exit code 0 for clean evaluation runs."""
    awk_path = Path("/app/reconcile.awk")
    res = subprocess.run(["gawk", "-f", str(awk_path)], capture_output=True, text=True)
    assert res.returncode == 0, f"Expected exit code 0 for clean evaluation, got {res.returncode}"
