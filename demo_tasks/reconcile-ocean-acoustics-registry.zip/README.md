# Ocean Acoustics Monte Carlo Registry Reconciliation

## Background & Task Narrative

Our ocean acoustics modeling team runs Monte Carlo acoustic propagation simulations across underwater bathymetry profiles using solvers like RAM-PE, BELLHOP, and KRAKEN. Over the past few months, run parameters logged in our legacy registry (`/app/data/run_registry.tsv`) drifted out of sync with our official methods documentation (`/app/data/methods_dossier.txt`) and Maven lockfiles (`/app/data/maven-dependency-lock.xml`).

Specifically, we found three main issues:
1. Legacy solver names like `BELLHOP_legacy` and `RAM_PE` were never updated to match standard release identifiers (e.g. `BELLHOP-2024` and `RAM-PE-MOD`).
2. Acoustic pressure tolerances were logged in mixed units—micropascals, millipascals, kilopascals, and raw Sound Pressure Levels (`dB_SPL`).
3. Dependency versions in the run records didn't match our pinned Maven lockfile coordinates (`groupId:artifactId:version`).

To fix this, we need an AWK utility (`/app/reconcile.awk`) that parses the registry and dependency lock, normalizes units to Pascals, sorts simulation steps by topological parent-child execution order, and generates a database migration script at `/app/migrations/V2__reconcile_registry.sql`.

## What the Solution Does

The solution script (`/app/solution/solve.sh`) generates `/app/reconcile.awk` which handles the following:

- Parses `data/maven-dependency-lock.xml` to match short library names with full Maven coordinate strings.
- Converts pressure metrics to Pascals (`Pa`). Decibel values like `120 dB_SPL` convert to `1.000000 Pa` using $P = 10^{\text{dB}/20} \times 10^{-6}$.
- Sorts database `UPDATE` statements by topological dependency depth so parent runs are updated before dependent child runs.
- Appends an inline `-- SHA256:<hash>` comment to each SQL statement.
- Signs the complete migration output with an inline `-- HMAC-SHA256:<signature>` comment using `/app/data/.secret_key`.
- Supports the `--json-summary` command-line flag to output JSON status and record counts before exiting.

## How to Test

You can run the test suite locally with `pytest`:

```bash
python -m pytest /tests/test_outputs.py
```

The verifier checks:
- `/app/reconcile.awk` exists and runs cleanly.
- `--json-summary` returns valid JSON with exit code 0.
- `V2__reconcile_registry.sql` contains correct topological ordering, converted Pascal tolerances, per-statement SHA256 hashes, and the HMAC-SHA256 signature.
